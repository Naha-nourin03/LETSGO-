var mongoose12 = require('mongoose')
var schema = mongoose12.Schema({
    campaign:String,
    Description:String,
    link:String,
    Location:String,
    Group:String,
    Date: String,
    Time: String, 
    Duration:Number,
    volunteers:Number,    
    Requirements:String,
    Name:String,
    Phone:Number
})
var Addmodel =  mongoose12.model("Location", schema);
module.exports=Addmodel