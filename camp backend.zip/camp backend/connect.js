var mongoose12 = require('mongoose')
mongoose12.connect("mongodb+srv://adarshcp:adarshcp02@cluster0.vfui1.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
    .then(() => {
    console.log("Database connected")
    })
    .catch((err) => {
        console.log(err)
    }
)