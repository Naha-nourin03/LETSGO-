//to import 
var express = require("express")
var cors = require("cors")
require("./connect")
var Addmodel=require("./models/add")
// to initialise
var app = express()

// middlewear
app.use(express.json())
app.use(cors());
// to create api
app.get('/trial', (req, res) => {
    res.send("Its our app")
})
// to run create a port for running 

app.post('/add', (req, res) => {
    res.send("Its our app")
})
app.post('/a', async(req, res) => {
    try {
        await Addmodel(req.body).save()
        res.send({message:"data added"})
    } catch (error) {
        console.log(error)
    }
})
app.get('/v', async (req, res) => {
  
    try {
        var addd = await Addmodel.find()
      res.send(addd)
    } catch (error) {
        console.log(error)
    }
    

})
app.delete('/delete/:id', async (req, res) => {
    try {
         await Addmodel.findByIdAndDelete(req.params.id)
        res.send({message:"Deleted succesfully"})
    } catch (error) {
        console.log(error)
    }


})
app.put('/update/:id', async (req, res) => {
  try {
      await Addmodel.findByIdAndUpdate(req.params.id, req.body)
      res.send({message:"Updated succesfully"})
  } catch (error) {
    console.log(error)
  }


})

     
app.listen(4008, () => {
    console.log("Port is running")
})
